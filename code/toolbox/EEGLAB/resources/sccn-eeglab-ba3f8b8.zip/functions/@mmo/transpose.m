function res = transpose(obj);

    res = ctranspose(obj, 0);
    
    
