README for Data S1: Archive of Auditory Stimuli

MANUSCRIPT TITLE:
[Insert Your Manuscript Title Here]

AUTHORS:
Peirun Song et al.

DESCRIPTION:
This dataset (Data S1) contains the complete set of auditory stimuli used in the experiments described in the main text and Supplementary Materials. The audio files are organized into four folders, categorized by subject species (Human vs. Rat) and acoustic environment (Real vs. Simulated).

-------------------------------------------------------------------------
DIRECTORY STRUCTURE AND FILE CONTENTS
-------------------------------------------------------------------------

1. FOLDER: Human_Real_Example
   Description: Real-world audio recordings used in human experiments.
   
   File Naming Convention: Human_Real_[Condition]_[StimulusID].wav
   
   - [Condition]: 
     "LowRevb" indicates recordings from the low-reverberation environment.
     "HighRevb" indicates recordings from the high-reverberation environment.
   - [StimulusID]: 
     Identifier for the specific sound sequence (e.g., "Reg4-4", "Reg4-4.01").

2. FOLDER: Human_Simulated
   Description: Simulated audio stimuli for human experiments with varying reflection levels.
   
   File Naming Convention: [Index]_[ReflectionLevel]_[StimulusID]_Reg.wav
   
   - [Index]: Unique numerical identifier (e.g., 001, 002).
   - [ReflectionLevel]: 
     Files with "reflectionLevel1", "reflectionLevel2", etc., correspond to specific simulated reflection intensities.
     Files without a "reflectionLevel" tag (e.g., "001_4_Reg") correspond to the baseline/anechoic condition.
   - [StimulusID]: Corresponds to the pattern parameters (e.g., "4", "4.01").

3. FOLDER: Rat_Real_Example
   Description: Real-world audio recordings used in rat experiments.
   
   File Naming Convention: Rat_Real_[Condition]_[StimulusID].wav
   
   - [Condition]: 
     "LowRevb" (Low Reverberation) vs. "HighRevb" (High Reverberation).
   - [StimulusID]: 
     Identifier matching the experimental protocols (e.g., "Reg4-4.4", "Reg4-4.6").

4. FOLDER: Rat_Simulated
   Description: Simulated audio stimuli for rat experiments.
   
   File Naming Convention: [Index]_TB_Reg_Dur[Duration]_[StimulusID]_No-Rep_[ReflectionLevel].wav
   
   - [Index]: Unique numerical identifier.
   - [Duration]: Duration of the stimulus (e.g., "Dur1000.9626" indicates approx 1000ms).
   - [ReflectionLevel]: 
     "reflectionLevel1", "reflectionLevel2" indicate simulated reflection intensities.
     Files without this tag indicate the baseline condition.
   - [StimulusID]: Pattern identifier (e.g., "4-4", "4-5").

-------------------------------------------------------------------------
TECHNICAL SPECIFICATIONS
-------------------------------------------------------------------------
- File Format: .wav
- Human Stimuli Sampling Rate: 384 kHz
- Rat Stimuli Sampling Rate: 97656 Hz
- Bit Depth: 32-bit

NOTES:
For detailed methodology regarding the generation of simulated sounds (including the definition of reflection levels) and the recording setup for real-world sounds, please refer to the "Materials and Methods" section of the main manuscript.